#!/bin/bash
# ============================================================
# Agent Studio — Atualiza repositório com Atlas + 13 agentes
# ============================================================
set -e

echo ""
echo "◈ Agent Studio — Push para GitHub"
echo "==================================="
echo ""

# Copia os arquivos novos para o repo existente
REPO_DIR="${1:-./agentes-studio}"

if [ ! -d "$REPO_DIR/.git" ]; then
  echo "❌ Não encontrei o repositório em: $REPO_DIR"
  echo "   Use: ./push.sh /caminho/para/agentes-studio"
  exit 1
fi

echo "📁 Copiando arquivos para $REPO_DIR..."

cp src/agents.js       "$REPO_DIR/src/agents.js"
cp src/AgentStudio.jsx "$REPO_DIR/src/AgentStudio.jsx"
cp src/main.jsx        "$REPO_DIR/src/main.jsx"
cp pixel_agents.py     "$REPO_DIR/pixel_agents.py"
cp README.md           "$REPO_DIR/README.md"

echo "✓ Arquivos copiados"

cd "$REPO_DIR"

git add .
git commit -m "feat: Atlas orchestrator + agent names (Lara, Marco, Nina...) + task board + approval gate

- Add Atlas as 13th orchestrator agent with robust system prompt
- Name all 12 specialists: Lara, Marco, Nina, Sofia, Theo, Kai, Rafa, Zoe, Alex, Leo, Max, Bia
- Add agents.js with centralized config and system prompts
- Add task board (Kanban) with approval gate for production
- Add office view with pixel avatars and speech bubbles
- Add notification system
- Add persistent task state in pixel_agents.py
- Update README with full feature list"

git push origin main

echo ""
echo "✅ Repositório atualizado!"
echo ""
echo "🔗 https://github.com/menezscri/agentes-studio"
echo ""
